export default function CollapseForm() {
    return (
        <div>
            <h1>Collapse Form</h1>
        </div>
    )
}