export default function Exercises() {
    return (
        <div>
            <h1>Exercises</h1>
        </div>
    )
}