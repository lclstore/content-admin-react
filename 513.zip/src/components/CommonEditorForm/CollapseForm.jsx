import styles from './CollapseForm.module.css';

export default function CollapseForm() {
    return (
        <div className={styles.collapseForm}>
            <h1>Collapse Form</h1>
        </div>
    )
}