export default function CommonList() {
    return (
        <div>
            <h1>Common List</h1>
        </div>
    )
}