export default () => {
    return (
        <div>
            <h1>Editor</h1>
        </div>
    )
}